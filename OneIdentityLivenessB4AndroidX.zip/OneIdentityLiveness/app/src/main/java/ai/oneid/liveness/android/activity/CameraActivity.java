package ai.oneid.liveness.android.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v8.renderscript.RenderScript;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.SparseArray;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.cameraview.CameraView;
import com.google.android.cameraview.CameraViewImpl;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.pedro.library.AutoPermissions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import cz.msebera.android.httpclient.Header;
import io.github.silvaren.easyrs.tools.Nv21Image;
import ai.oneid.liveness.android.R;
import ai.oneid.liveness.android.data.AsynRestClient;


public class CameraActivity extends AppCompatActivity
{
    private CameraView cameraView;
    public String appPath = "/OneIdentity";
    public TextView textGesture;
    public TextView textInstruction;
    //Do nothing
    public int step = 0;
    public RenderScript rs;
    public int counter = 0;
    public static FaceDetector detector;
    public ProgressDialog progressDialog;
    public String imageName = "";
    public String imagePath = "";
    public String token = "";
    public String apikey = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        setContentView(R.layout.activity_camera);

        token = getIntent().getExtras().getString("token");
        apikey = getIntent().getExtras().getString("apikey");

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Processing File");
        progressDialog.setMessage("Uploading...");
        progressDialog.setCancelable(true);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

        if(detector == null)
        detector = new FaceDetector.Builder(this)
                .setTrackingEnabled(false)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS).setLandmarkType(FaceDetector.ALL_LANDMARKS).setMode(FaceDetector.ACCURATE_MODE)
                .setProminentFaceOnly(true)
                .build();

        if (!detector.isOperational())
            new AlertDialog.Builder(this).setMessage("Could not set up the face detector!").show();

        rs = RenderScript.create(this);
        cameraView = findViewById(R.id.camera_view);
        cameraView.setOnFocusLockedListener(new CameraViewImpl.OnFocusLockedListener() {
            @Override
            public void onFocusLocked() {
            }
        });
        cameraView.setOnPictureTakenListener(new CameraViewImpl.OnPictureTakenListener() {
            @Override
            public void onPictureTaken(Bitmap bitmap, int rotationDegrees) {
                Matrix matrix = new Matrix();
                matrix.postRotate(-rotationDegrees);
                //return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
            }
        });
        cameraView.setOnTurnCameraFailListener(new CameraViewImpl.OnTurnCameraFailListener() {
            @Override
            public void onTurnCameraFail(Exception e) {
                Toast.makeText(CameraActivity.this, "Switch Camera Failed. Does you device has a front camera?",
                        Toast.LENGTH_SHORT).show();
            }
        });
        cameraView.setOnCameraErrorListener(new CameraViewImpl.OnCameraErrorListener() {
            @Override
            public void onCameraError(Exception e) {
                Toast.makeText(CameraActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        cameraView.setOnFrameListener(new CameraViewImpl.OnFrameListener() {
            @Override
            public void onFrame(final byte[] data, final int width, final int height, int rotationDegrees) {
                if(apiKeyVerified) {
                    counter++;
                    Matrix matrix = new Matrix();
                    matrix.postRotate(-rotationDegrees + 180);
                    Bitmap bitmap = Nv21Image.nv21ToBitmap(rs, data, width, height);
                    Bitmap converted = bitmap.copy(Bitmap.Config.RGB_565, false);
                    bitmap.recycle();
                    final Bitmap bitmap2 = Bitmap.createBitmap(converted, 0, 0, converted.getWidth(), converted.getHeight(), matrix, true);
                    //converted.recycle();
                    Frame frame = new Frame.Builder().setBitmap(bitmap2).build();
                    final SparseArray<Face> faces = detector.detect(frame);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.e("Face detected", faces.size() + " " + faces.toString());
                            if (faces.size() > 1 && step < 4) {
                                step = 0;
                                textGesture.setText("");
                                textInstruction.setText("Make sure only 1 face is within the camera frame");
                            } else if (faces.size() == 0 && step < 4) {
                                step = 0;
                                textGesture.setText("");
                                textInstruction.setText("Place your face inside the camera frame");
                            } else {
                                if(step > 4)
                                {
                                    return;
                                }

                                Face face = faces.get(0);
                                if (face != null) {
                                    Log.d("Face", "valid face" + faces.get(0).toString());
                                }
                                else
                                {
                                    Log.d("Face", "Invalid face" + faces.get(0).toString());
                                }
                                if (step == 0) {
                                    step++;
                                    textGesture.setText("");
                                } else if (step == 1) {
                                    textGesture.setText("TURN LEFT");
                                    textInstruction.setText("Turn your face to the left");
                                    if (face != null) {
                                        Log.d("EulerY", face.getEulerY() + "");
                                        if (face.getEulerY() >= 20) {
                                            step++;
                                        }
                                    }
                                } else if (step == 2) {
                                    textGesture.setText("TURN RIGHT");
                                    textInstruction.setText("Turn your face to the right");
                                    if (face != null) {
                                        Log.d("EulerY", face.getEulerY() + "");
                                        if (face.getEulerY() <= -20) {
                                            step++;
                                        }
                                    }
                                } else if (step == 3) {
                                    textGesture.setText("LOOK At THE SCREEN");
                                    textInstruction.setText("Look at the screen");
                                    if (face != null) {
                                        Log.d("EulerY", face.getEulerY() + "");
                                        //if (face.getIsSmilingProbability() >= 0.7) {
                                        //    step++;
                                        //}
                                        if (face.getEulerY() > -10 && face.getEulerY() < 10) {
                                            step++;
                                        }
                                    }
                                } else if (step == 4) {
                                    textGesture.setText("THANK YOU");
                                    textInstruction.setText("Verification completed. Please wait while we completing the upload process");

                                    try {
                                        imageName = fileNameGenerator(CameraActivity.this) + ".jpg";
                                        imagePath = Environment.getExternalStorageDirectory().getAbsolutePath() + appPath + "/" + imageName;
                                        File file = new File(imagePath);
                                        FileOutputStream out = new FileOutputStream(file);
                                        bitmap2.compress(Bitmap.CompressFormat.JPEG, 100, out);
                                        step++;
                                        upload();
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        }
                    });
                }
            }
        });

        textGesture = findViewById(R.id.text_gesture);
        textInstruction = findViewById(R.id.text_instruction);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        ViewGroup.LayoutParams params = cameraView.getLayoutParams();
        params.height = Integer.parseInt(Math.round(height*0.6) + "");
        //params.width = width;
        cameraView.requestLayout();
        checkAPIKey();
        AutoPermissions.Companion.loadAllPermissions(this, 1);

        createDirectoryIfNotExist(Environment.getExternalStorageDirectory().toString() + appPath);
    }

    public void createDirectoryIfNotExist(String directoryPath) {
        try {
            File dir = new File(directoryPath);
            if (!dir.exists()) {
                dir.mkdir();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        createDirectoryIfNotExist(Environment.getExternalStorageDirectory().toString() + appPath);
    }

    public static String fileNameGenerator(Context context)
    {
        Calendar now = Calendar.getInstance();
        Date date = now.getTime();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddhhmmss");
        String formattedDate = format.format(date);

        return getDeviceId(context) + "-" + formattedDate;
    }

    public static String getDeviceId(Context context)
    {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public void upload()
    {
        AsynRestClient.upload(token, "selfie", imagePath, apikey, new AsyncHttpResponseHandler()
        {
            @Override
            public void onStart() {
                progressDialog.show();
            }

            @Override
            public void onFinish() {
                progressDialog.dismiss();
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                String responseString = new String(response);
                Log.e("Upload response", responseString);
                try {
                    JSONObject jsonObject = new JSONObject(responseString.replace("null", "\"\""));

                    if(jsonObject.has("error"))
                    {
                        JSONObject errorObject = jsonObject.getJSONObject("error");
                        alert(errorObject.getString("type"), errorObject.getString("message"));
                        return;
                    }
                    String status = jsonObject.getString("status");
                    if (status.equals("200"))
                    {
                        String fileName = jsonObject.getString("file_name");

                        JSONObject responseObject = new JSONObject();
                        responseObject.put("status", "200");
                        responseObject.put("type", "ok");
                        responseObject.put("message", "Liveness verification successful");
                        responseObject.put("selfie_image", fileName);
                        Intent data = new Intent();
                        data.setData(Uri.parse(responseObject.toString()));
                        setResult(RESULT_OK, data);
                        finish();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                String responseString = new String(errorResponse);
                Log.e("Upload response", responseString);
            }

            @Override
            public void onProgress(long bytesWritten, long totalSize) {
                int progress = Math.round((bytesWritten/totalSize)*100);
                progressDialog.setProgress(progress);
                progressDialog.setMax(100);
            }
        });
    }

    public void alert(final String title, String message)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        if(title.equals("api_key") || title.equals("rate_limit") || title.equals("internal_server_error"))
                        {
                            finish();
                        }
                    }
                });
        alertDialog.show();
    }

    private void message(String content, boolean important) {
        int length = important ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT;
        Toast.makeText(this, content, length).show();
    }

    @Override
    public void onResume()
    {
        super.onResume();
        cameraView.start();
        //Set s = cameraView.getSupportedAspectRatios(); // This is just to make sure the set is not empty
        //cameraView.setAspectRatio(AspectRatio.of(4,6), true);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        cameraView.stop();
    }

    public boolean apiKeyVerified = false;
    private void checkAPIKey()
    {
        textInstruction.setText("Validating API Key...");
        JSONObject jsonObject = new JSONObject();
        AsynRestClient.validateKey(this, jsonObject.toString(), apikey, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
            }

            @Override
            public void onFinish() {
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String responseString = new String(responseBody);
                Log.e("Response", responseString);
                try {
                    JSONObject jsonObject = new JSONObject(responseString);
                    if(jsonObject.has("error"))
                    {
                        JSONObject errorObject = jsonObject.getJSONObject("error");
                        alert(errorObject.getString("type"), errorObject.getString("message"));
                        return;
                    }
                    String status = jsonObject.getString("status");
                    if (status.equals("200"))
                    {
                        apiKeyVerified = true;
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                // called when response HTTP status is "4XX" (eg. 401, 403, 404)
                alert(getString(R.string.error), getString(R.string.error_please_try_again));
                String responseString = new String(errorResponse);
                Log.e("Response", responseString);
            }
        });
    }
}