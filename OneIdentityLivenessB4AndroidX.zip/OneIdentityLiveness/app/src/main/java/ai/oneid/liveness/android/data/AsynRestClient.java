package ai.oneid.liveness.android.data;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.MySSLSocketFactory;
import com.loopj.android.http.RequestParams;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import cz.msebera.android.httpclient.entity.StringEntity;

public class AsynRestClient {
    public static String serverUrl = "https://api.1id.ai/v2/";
    //public static String serverUrl = "https://pixel.ddns.net/indyv2/";
    public static String uploadUrl = serverUrl + "upload" ;
    public static String checkAPIKeyUrl = "https://api.1id.ai/v2/mobile-liveness" ;
    public static String headerAPIKey = "9c24abc8797a4554a54f3c6c26c705d9";

    public static int timeOutMili = 20000;
    private static AsyncHttpClient client = new AsyncHttpClient();


    public static void validateKey(Context context, String data, String apiKey, AsyncHttpResponseHandler responseHandler) {
        client.setSSLSocketFactory(MySSLSocketFactory.getFixedSocketFactory());
        client.setTimeout(timeOutMili);
        client.addHeader("Authorization", "Bearer " + apiKey);
        StringEntity entity = null;
        try {
            entity = new StringEntity(data);
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        client.post(context, checkAPIKeyUrl, entity, "application/json", responseHandler);
    }

    public static void upload(String token, String type, String imagePath, String apiKey, AsyncHttpResponseHandler responseHandler) {
        client.setSSLSocketFactory(MySSLSocketFactory.getFixedSocketFactory());
        client.setTimeout(timeOutMili);
        client.addHeader("Authorization", "Bearer " + apiKey);
        File myFile = new File(imagePath);
        RequestParams params = new RequestParams();
        try {
            params.put("token", token);
            params.put("type", type);
            params.put("file", myFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        client.post(uploadUrl, params, responseHandler);
    }
}